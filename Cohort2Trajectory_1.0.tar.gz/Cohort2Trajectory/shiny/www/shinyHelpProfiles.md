## Profiles

**This tab is used for checking patients trajectories in the generated data**

### Profiles

Select a patient id from the source and see information about the generated trajectory.

When modifying the **Length of allowed inactivity** and selecting **Plot type: Distinguishable** you can remove the "OUT OF COHORT" states which surpass the length of allowed inactivity.

